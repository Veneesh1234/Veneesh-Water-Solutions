VENEESH BOREWELLS website
- Open index.html in a browser to preview.
- The logo is included as editable SVG in the HTML.
- Phone numbers and WhatsApp enquiry links are included.
- To publish free, upload index.html to Netlify Drop (app.netlify.com/drop) or deploy the folder with GitHub Pages.
- Before publishing, verify all phone numbers and service-area details.
